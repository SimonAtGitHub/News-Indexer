/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.buffalo.cse.irf14.query;

/**
 *
 * @author san
 */
public final class QueryParserExceptionMessages {
    
    public static final String INVALID_DEFAULT = "The defaultOperator provided should be either AND | OR";
    
}
