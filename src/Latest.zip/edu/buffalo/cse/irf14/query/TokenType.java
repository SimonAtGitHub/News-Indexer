/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.buffalo.cse.irf14.query;

/**
 *
 * @author san
 */
public enum TokenType {
    
  TERM, OPEN_PAREN, CLOSE_PAREN, AND_OP, OR_OP, NOT_OP, OPEN_QOUTES, CLOSE_QOUTES, START, END, INDEX_TYPE
    
};
